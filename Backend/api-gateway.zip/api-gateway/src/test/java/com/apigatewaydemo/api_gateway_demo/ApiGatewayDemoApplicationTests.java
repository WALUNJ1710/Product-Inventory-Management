package com.apigatewaydemo.api_gateway_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.wipro.ApiGatewayApplication;

@SpringBootTest(classes = ApiGatewayApplication.class)
class ApiGatewayDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
